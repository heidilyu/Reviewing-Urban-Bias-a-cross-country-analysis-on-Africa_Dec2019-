cproduc_bycountry <-
  X3_Crop_Production %>%
  group_by(economy)%>%
  summarise(sum_produc_0217 = sum(cproduc_0217, na.rm = TRUE))%>%
  ungroup

cproduc_bycountry

cproduc_bycountry_0717 <-
  X3_Crop_Production %>%
  group_by(economy)%>%
  summarise(sum_produc_0717 = sum(cproduc_0717, na.rm = TRUE))%>%
  ungroup

cproduc_bycountry_0717

cproduc_bycountry_byyear <-
  X3_Crop_Production %>%
  group_by(economy, year)%>%
  summarise(sum_produc = sum(, na.rm = TRUE))%>%
  ungroup

cproduc_bycountry_0717
